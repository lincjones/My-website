var minimum = 1;
var maximum = 100;
var int1 = Math.floor(Math.random() * (maximum - minimum + 1)) + minimum;
var int2 = Math.floor(Math.random() * (maximum - minimum + 1)) + minimum;

document.getElementById("question").innerHTML = int1 + "+" + int2;

function Submit()
{
    var correctAnswer = int1 + int2;
    var userAnswer = document.getElementById("answer").value;

    if (userAnswer == correctAnswer)
    {
        document.getElementById("output").innerHTML = "CORRECT!!!";
    }
    else if (userAnswer != correctAnswer)
    {
        document.getElementById("output").innerHTML = userAnswer + " is WRONG!!!";
    }
    
    setTimeout(function(){
        window.location.reload(1);
     }, 5000);

}
