const nameArray = 
[
    "Rashida Tousignant"  ,"Saturnina Hauff"  ,"Su Cuffie"  ,"Albina Salvetti"  ,"Lorriane Viveros"  ,"Loretta Alvarez"  ,"Senaida Bartlett"  ,"Marilou Janicki"  ,"Suzy Calder"  ,"Laraine Hupp"  ,"Meghan Heslin"  ,"Flo Ferriera"  ,"Lashell Wahl"  ,"Darcey Galley"  ,"Marylee Blackerby"  ,"Dimple Mcgavock"  ,"Cythia Amann"  ,"Dorotha Keane"  ,"Alesia Barrie"  ,"Hattie Orvis"  ,"Asuncion Soloman"  ,"Elene Hulett"  ,"Lyda Cipriano"  ,"Katelyn Garmany"  ,"Rina Shumate"  ,"Pearl Correll"  ,"Marjorie Mounce"  ,"Alaine Rainville"  ,"Tawnya Resh"  ,"Nelda Karnes"  ,"Fatima Mannix"  ,"Joni Peel"  ,"Latashia Peguero"  ,"Shirly Whobrey"  ,"Nicholle Swims"  ,"Mei Shankles"  ,"Kanisha Hodgson"  ,"Delphine Kok"  ,"Annabell Ormiston"  ,"Gillian Labarbera"  ,"Elidia Mass"  ,"Princess Schachter"  ,"Criselda Stansberry"  ,"Nicolasa Ontiveros"  ,"Tai Vandenberg"  ,"Hermelinda Ranck"  ,"Sebrina Sevigny"  ,"Kirsten Nocera"  ,"Loraine Walts"  ,"Juanita Krol"," Lavelle Horn"  ,"Nickie Gaetano"  ,"Alyce Malmberg"  ,"Nicolette Manfredi"  ,"Isidra Wille"  ,"Felipa Fleischer"  ,"Nilda Treat"  ,"Carmelia Rhea"  ,"Cristen Mattis"  ,"Onie Lammert"  ,"Amalia Hyndman"  ,"Marya Ferrell"  ,"Alison Mclemore"  ,"Lavonia Mires"  ,"Viva Legette"  ,"Moon Sampley"  ,"Tameka Christ"  ,"Pamelia Beaubien"  ,"Mireille Montesinos"  ,"Latonya Forest"  ,"Chiquita Eggers"  ,"Salina Frederick"  ,"Kerstin Deputy"  ,"Marguerita Zeno"  ,"Judith Wilkens"  ,"Renay Widman"  ,"Marivel Zuber"  ,"Vada Ackerson"  ,"Cheryll Vera"  ,"Star Koopman"  ,"Cassondra Eaglin"  ,"Delila Colligan"  ,"Ayako Vales"  ,"Dolly Borden"  ,"Marlo Emmer"  ,"Althea Ancona"  ,"Suzette Forehand"  ,"Emmy Lathem"  ,"Scarlet Senegal"  ,"Tuyet Archambeault"  ,"Luanne Massa"  ,"Lilla Sumler"  ,"Catherina Hastings"  ,"Madelene Gentner"  ,"Meta Muraoka"  ,"Mitsuko Poynter"  ,"Estefana Marbury"  ,"Jerrica Calkins"  ,"Katia Wininger"  ,"Norah Kendra"," Barrett Dooley"  ,"Frances Reller"  ,"Chadwick Hein"  ,"Hector Wilgus"  ,"Logan Henningsen"  ,"Shad Spalding"  ,"Elden Stearman"  ,"Dana Wilhoit"  ,"Antonia Hemstreet"  ,"Al Rau"  ,"Thomas Nardone"  ,"Damion Gries"  ,"Harris Ransome"  ,"Irving Bluitt"  ,"Freddie Wickham"  ,"Tyson Rivero"  ,"Lanny Sereno"  ,"Renato Ezzell"  ,"Oliver Hausner"  ,"Vincent Matt"  ,"Brant Kocsis"  ,"Pedro Cervantez"  ,"Lamar Nellum"  ,"Jamie Lahti"  ,"Jonas Proudfoot"  ,"Mitch Priestly"  ,"Martin Appleton"  ,"Noe Felps"  ,"Harvey Shellhammer"  ,"Ulysses Alejo"  ,"Jim Fahy"  ,"Lorenzo Gannon"  ,"Miquel Pierson"  ,"Gus Lain"  ,"Trevor Carboni"  ,"Winston Bonk"  ,"Lauren Wichman"  ,"Angel Keeling"  ,"Ahmed Holtzen"  ,"Jimmy Nussbaum"  ,"Alonso Litteral"  ,"Kraig Weishaar"  ,"Danny Kesner"  ,"Kurt Wineinger"  ,"Willis Bobbitt"  ,"Yong Gales"  ,"Christoper Spielman"  ,"Carol Desper"  ,"Quinn Lisenby"  ,"Eli Rozek"," Porfirio Brumm"  ,"Stanton Browne"  ,"Fermin Hollingshead"  ,"Jerome Frum"  ,"Hershel Waggener"  ,"Octavio Staudt"  ,"Jean Quintanar"  ,"Stephan Gerow"  ,"Noel Sterns"  ,"Preston Husby"  ,"Curtis Streets"  ,"Sean Fears"  ,"Young Rana"  ,"Pedro Brazeau"  ,"Louie Maltby"  ,"Jewel Lannon"  ,"Dannie Sulik"  ,"Quincy Janicki"  ,"Seymour Scoby"  ,"Danny Blann"  ,"Javier Lightle"  ,"Randy Geibel"  ,"Lewis Racca"  ,"Tuan Freeburg"  ,"Tobias Sisto"  ,"Marquis Bronstein"  ,"Lon Wildman"  ,"Barrett Greene"  ,"Freddy Ippolito"  ,"Forest Sinegal"  ,"Rigoberto Cockburn"  ,"Spencer Destefano"  ,"Isaac Rambo"  ,"Jay Eaker"  ,"Gordon Heilman"  ,"Anibal Danforth"  ,"Emanuel Coaxum"  ,"Gregory Graney"  ,"Rudolph Maharaj"  ,"Denver Rawling"  ,"Moses Eberhart"  ,"Demetrius Juntunen"  ,"Terrence Spector"  ,"Ezekiel Delbosque"  ,"Gustavo Clogston"  ,"Gene Kellar"  ,"Keneth Mickelson"  ,"Mitchell Dabbs"  ,"Willian Leight"  ,"Johnnie Shillings"
]

const months = 
[
    "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" 
]

const hairColors = 
[
    "Brown", "Blonde", "Black"
]

const civilStatuses = 
[
    "Married", "Single", "Widowed", "Divorced"
]

const educationStatuses =
[
    "Highschool dropout", "Some college", "Associates degree", "College degree", "Graduate Degree"
] 

const races = 
[
    "American Indian or Alaska Native", "Asian", "Black or African American", "Hispanic or Latino", "Native Hawaiian or Other Pacific Islander", "White"
]


function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1) ) + min;
}

$.getscript("resources/js/progressbar.js",function(){
    move();
    });
    

function Start()
{
    setTimeout(() => {  Generate(); }, 1100);
    move()
}

function Generate() {

    var name = nameArray[Math.floor(Math.random()*nameArray.length)];
    document.getElementById("name").innerHTML = "Name: " + name

    var age = Math.floor(Math.random() * 65) + 21
    document.getElementById("age").innerHTML = "Age: " + age
    
    var genderVar = Math.floor(Math.random() * 10);

    var gender;

    if (genderVar <= 5)
    {
        document.getElementById("gender").innerHTML = "Gender: Male";
        gender = "Male";
    }

    else
    {
        document.getElementById("gender").innerHTML = "Gender: Female";
        gender = "Female";
    }

    var race = races[Math.floor(Math.random()*races.length)];
    document.getElementById("race").innerHTML = "Race: " + race;


    var birthdayMonth = months[Math.floor(Math.random()*months.length)];
    var birthdayDay = Math.floor(Math.random() * 29) + 1;
    var birthday = birthdayMonth + " " +  birthdayDay;
    document.getElementById("birthday").innerHTML = "Birthday: " + birthday;

    var nameWOutSpaces = name.split(" ").join("");
    var email = nameWOutSpaces + "@gmail.com"
    document.getElementById("email").innerHTML = "Email: " + email;
    
    var foot = getRndInteger(5, 6);
    var inches = getRndInteger(0, 11);
    var height = foot + "\'" + inches + "\"";
    document.getElementById("height").innerHTML = "Heght: " + height;

    var weight = getRndInteger(99, 400);
    document.getElementById("weight").innerHTML = "Weight:" + weight;

    var hairColor = hairColors[Math.floor(Math.random()*hairColors.length)];
    document.getElementById("hairColor").innerHTML = "Hair color: " + hairColor;

    var civilStatus = civilStatuses[Math.floor(Math.random()*civilStatuses.length)];
    document.getElementById("civilStatus").innerHTML = "Civil Status: " + civilStatus;

    var education = educationStatuses[Math.floor(Math.random()*educationStatuses.length)];
    document.getElementById("education").innerHTML = "Education: " + education;
}